# NoNetflixAutoAds

Chrome Extension to remove the pesky auto playing ads on Netflix. 

Zipthis is the folder that has the live version ont he chrome web store. 

[Add To Chrome Here](https://chrome.google.com/webstore/detail/netflix-es-enhancement-su/chgnjnikegkdcolabpjkijgdhcklneja/)
